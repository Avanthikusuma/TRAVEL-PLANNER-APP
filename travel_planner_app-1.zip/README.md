# 🌍 Travel Planner App

A simple and modern travel planner application.

## Features
- Add travel destinations
- Beautiful UI
- Responsive design
- Travel gallery

## Technologies Used
- HTML
- CSS
- JavaScript

## Author
Avanthikusuma
